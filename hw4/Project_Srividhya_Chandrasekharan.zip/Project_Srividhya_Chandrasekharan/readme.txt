The submission contains 3 python programs to generate k means clustering. 
1)kmeans.py - works on TwoDimEasy and TwoDimHard datasets.Takes in the dataset file name and the value of k as command line arguments.
To execute : python kmeans.py TwoDimEasy.csv 2

2)wine.py : works on wine dataset
To execute : python kmeans.py TwoDimEasy.csv 2

3) off_the_shelf.py - scikit learn's kmeans code.
